package com.example.privateaihub

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var contentView: TextView
    private var latestText: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        handleIncoming(intent)
        refreshInbox()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIncoming(intent)
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 36, 36, 24)
        }
        val title = TextView(this).apply {
            text = "私人 AI 资料中枢"
            textSize = 24f
            gravity = Gravity.CENTER_VERTICAL
        }
        status = TextView(this).apply {
            text = "资料只保存在本应用私有目录；不会自动上传。"
            textSize = 14f
            setPadding(0, 16, 0, 16)
        }
        fun button(label: String, action: () -> Unit) =
            Button(this).apply { text = label; setOnClickListener { action() } }

        root.addView(title)
        root.addView(status)
        root.addView(button("选择文件 / PDF / 图片", ::pickFiles))
        root.addView(button("把当前文字交给 ChatGPT", ::shareText))
        root.addView(button("刷新资料列表", ::refreshInbox))
        root.addView(button("清空本次文字", {
            latestText = ""
            contentView.text = "尚未导入文字。"
            status.text = "当前文字已清空。"
        }))
        val scroll = ScrollView(this)
        contentView = TextView(this).apply {
            textSize = 15f
            setPadding(0, 20, 0, 20)
            text = "尚未导入文字。"
        }
        scroll.addView(contentView)
        root.addView(scroll, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f
        ))
        setContentView(root)
    }

    private fun handleIncoming(incoming: Intent?) {
        if (incoming == null) return
        try {
            when (incoming.action) {
                Intent.ACTION_SEND -> {
                    val text = incoming.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                    if (!text.isNullOrBlank()) {
                        latestText = text
                        saveText(text)
                    }
                    val uri = incoming.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
                    if (uri != null) copyUri(uri)
                }
                Intent.ACTION_SEND_MULTIPLE -> {
                    val uris = incoming.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)
                    uris?.forEach { copyUri(it) }
                }
            }
            refreshInbox()
        } catch (e: Exception) {
            status.text = "导入未完成：${e.message ?: "未知错误"}"
        }
    }

    private fun pickFiles() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        }
        startActivityForResult(i, 1001)
    }

    @Deprecated("Kept simple for broad device compatibility in this starter project")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK && data != null) {
            try {
                data.clipData?.let { clip ->
                    for (i in 0 until clip.itemCount) copyUri(clip.getItemAt(i).uri)
                } ?: data.data?.let { copyUri(it) }
                refreshInbox()
            } catch (e: Exception) {
                status.text = "文件导入失败：${e.message}"
            }
        }
    }

    private fun inboxDir(): File = File(filesDir, "inbox").apply { mkdirs() }

    private fun safeName(raw: String): String =
        raw.replace(Regex("[^A-Za-z0-9._-]"), "_").take(80).ifBlank { "imported_file" }

    private fun saveText(text: String) {
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        File(inboxDir(), "shared_$stamp.txt").writeText(text)
        status.text = "已接收文字并保存在本机。"
        contentView.text = text
    }

    private fun copyUri(uri: Uri) {
        val name = queryName(uri) ?: "shared_${System.currentTimeMillis()}"
        val target = File(inboxDir(), "${System.currentTimeMillis()}_${safeName(name)}")
        contentResolver.openInputStream(uri)?.use { input ->
            target.outputStream().use { output -> input.copyTo(output) }
        } ?: throw IllegalStateException("系统未能读取所选文件")
        status.text = "已导入：${target.name}"
    }

    private fun queryName(uri: Uri): String? {
        return try {
            contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
                null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Exception) { null }
    }

    private fun refreshInbox() {
        val items = inboxDir().listFiles()?.sortedByDescending { it.lastModified() } ?: emptyList()
        val listing = if (items.isEmpty()) "资料库目前是空的。" else
            items.joinToString("\n\n") { "• ${it.name}  (${it.length()} bytes)" }
        if (latestText.isBlank()) contentView.text = listing
        else contentView.text = "最近接收的文字：\n\n$latestText\n\n本地资料：\n$listing"
        status.text = "本地资料 ${items.size} 项。不会在后台扫描其他 App。"
    }

    private fun shareText() {
        if (latestText.isBlank()) {
            Toast.makeText(this, "请先从其他 App 分享文字过来。", Toast.LENGTH_SHORT).show()
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, latestText)
        }
        startActivity(Intent.createChooser(send, "选择 ChatGPT 或其他接收应用"))
    }
}
